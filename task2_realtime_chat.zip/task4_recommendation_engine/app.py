
from flask import Flask, request, jsonify
import random

app = Flask(__name__)

# Dummy recommendations
sample_recommendations = {
    "user1": ["Movie A", "Movie B", "Movie C"],
    "user2": ["Product X", "Product Y", "Product Z"]
}

@app.route('/recommend', methods=['GET'])
def recommend():
    user = request.args.get('user', 'user1')
    return jsonify({
        "user": user,
        "recommendations": sample_recommendations.get(user, random.sample(sample_recommendations['user1'], 2))
    })

if __name__ == "__main__":
    app.run(debug=True)
    